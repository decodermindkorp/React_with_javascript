
const hasIdea = false ;

const Idea = new Promise ( (resolve,reject)=> {

      if(!hasIdea)
      {
           const genIdea = {

                    Ideaname: 'React',
                    Implimention : 'In Project',
                    purpose : 'Create Project'

           }
           resolve(genIdea)

      }
      else 
      {
          reject(new Error('Already Generated Idea'))

      }

})

   const getidea = (Idea) => 
   {
          const Sheduleidea = `${Idea.Ideaname} has been shedule ${Idea.Implimention} for this ${Idea.purpose}`;

          return Promise.resolve(Sheduleidea);
   }


Idea 
   .then (getidea)
  .then((res)=> {
     console.log(JSON.stringify(res))

  })

  .catch((err)=> {
      console.log(err.masege)

  })
