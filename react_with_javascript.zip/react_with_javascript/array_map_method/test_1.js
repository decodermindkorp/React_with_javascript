// =======array map function=============//
// =========syntax of array map========//

    // const myarray= newarray.map( function callback(element,index,array)
        // {
            //return value of myarray
        // }[thisarg]
    // )

    // Example
    // Q: Each number is an array is dobuled

    const makeDobuled=(arr) => 
    {
    //    return arr;
        let data = arr.map((val)=>
        {
            return val * 2;
        })

        return data;
    }

    console.log(makeDobuled([2,4,10]))




    // second way here 

    
const number = [2,4,6,8,10];

const myFun = (num) => 
{
    return num * 2;
}

const getvalue = number.map(myFun);


console.log(getvalue);
console .log (number);