// take an array of number and make them string

 function converTostring(arr)
 {
      const data = arr.map((e)=> {

        return e.toString();
      });
      return data;
 }

 console.log(converTostring([2,3,4.5,6]));
