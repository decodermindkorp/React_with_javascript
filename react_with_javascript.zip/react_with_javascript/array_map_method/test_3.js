// capatalize each of an array  of names


  const toUppercase =(arr) => {

     let getData =  arr.map( q => q.toUpperCase());

     console.log(getData);

  }
   
  toUppercase(['dipayan','amit','rajesh','daraksha']);
  