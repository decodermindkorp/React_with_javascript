// make an array of the string of names

const readName=(arr)=>
{
      const getData= arr.map((e)=>{

        return 'Name is '+  e.name +' Age is ' +  e.age;
      });

      return getData;

}

console.log(readName([
    {
        name:'Dipayan',
        age:25
    },
    {
        name:'Amit',
        age:26
    },
    {
        name:'Subha',
        age: 28
    }


]));


// second way ======



const getName=(arr)=>
{
      const readData= arr.map((e)=>{
        
        if(e.age>18)
        {
            console.log(e.name + 'you are aged '+ e.age );  
        }
        else
        {
            console.log('no you are not aged');

        }
        return 'Name is '+  e.name +' Age is ' +  e.age;
        
      });

      return readData;

}

console.log(getName([
    {
        name:'Dipayan',
        age:25
    },
    {
        name:'Amit',
        age:26
    },
    {
        name:'Subha',
        age: 28
    }


]));
