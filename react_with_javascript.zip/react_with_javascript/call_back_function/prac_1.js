
//1.simple function ========

const addTwoItem = (a) => {

    return a+ 2;   

}
console.log(addTwoItem(12));


// 2. callback function example

function map (array, callback)
{
   const newarray =[]; 
   
   for (i=0 ; i< array.length; i++)
   {
    newarray.push(callback(array[i]));
   }

     return newarray ;
}

 console.log(map([1,2,3,4] ,addTwoItem));